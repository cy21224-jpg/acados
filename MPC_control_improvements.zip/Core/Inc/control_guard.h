/** @file control_guard.h
 *  @brief HALに依存しない数値検査・DAC変換・任意の加速度制限。
 *  DACの式と範囲は既存mainの変換式および12bit範囲に合わせる。
 */
#ifndef CONTROL_GUARD_H
#define CONTROL_GUARD_H
#include <stddef.h>
#include <stdint.h>

enum {
    CONTROL_FAULT_NONE = 0,
    CONTROL_FAULT_SENSOR = 1,
    CONTROL_FAULT_INVERSE = 2,
    CONTROL_FAULT_MASS = 3,
    CONTROL_FAULT_OBSERVER = 4,
    CONTROL_FAULT_ACCELERATION = 5,
    CONTROL_FAULT_CURRENT = 6,
    CONTROL_FAULT_CONFIGURATION = 7,
    CONTROL_FAULT_HAL = 8
};

typedef struct {
    uint16_t code[3];
    float applied_current[3];
    uint32_t saturated_mask;
} ControlDacCommand;

int Control_AllFinite(const float *values, size_t count);
int Control_EkfResultValid(const float state[4], const float covariance[4][4]);
int Control_InverseValid(const float matrix[3][3], const float inverse[3][3]);
int Control_PrepareDac(const float requested_current[3], ControlDacCommand *result);

/* max_acceleration / max_jerk の0は無効。負値・非有限値は設定エラー。
 * 制限を両方指定した場合、加速度の絶対上限を優先する。
 * flags: bit0=加速度上限、bit1=変化率制限、bit2=上限優先で変化率を超えた。
 */
int Control_LimitAcceleration(float requested, float previous, float dt,
                             float max_acceleration, float max_jerk,
                             float *result, uint32_t *flags);
#endif
