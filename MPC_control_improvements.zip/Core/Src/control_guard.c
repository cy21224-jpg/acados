/** @file control_guard.c
 *  @brief 制御入力の検査と変換。機械固有の許容加速度は決め打ちしない。
 */
#include "control_guard.h"
#include <math.h>

/* 配列全体を検査し、途中のNaN/Infも拒否する。 */
int Control_AllFinite(const float *values, size_t count)
{
    if (values == NULL) return 0;
    for (size_t n = 0; n < count; ++n)
        if (!isfinite(values[n])) return 0;
    return 1;
}

/* EKF本体は変更せず、非有限値・負の共分散対角を次周期へ持ち越さない。
 * 共分散全体の正定性やパラメータの物理的正しさまでは保証しない。
 */
int Control_EkfResultValid(const float state[4], const float covariance[4][4])
{
    if (!Control_AllFinite(state, 4) || covariance == NULL) return 0;
    for (int r = 0; r < 4; ++r) {
        if (!Control_AllFinite(covariance[r], 4) || covariance[r][r] < 0.0f)
            return 0;
    }
    return 1;
}

/* 逆行列の有限性と両側残差を検査する。
 * 1e-3は無次元の数値残差の許容値であり、関節角の安全余裕ではない。
 * 近特異姿勢でも残差が小さければ通るため、可動範囲の監視は別に必要。
 */
int Control_InverseValid(const float matrix[3][3], const float inverse[3][3])
{
    if (matrix == NULL || inverse == NULL) return 0;
    for (int r = 0; r < 3; ++r)
        if (!Control_AllFinite(matrix[r], 3) || !Control_AllFinite(inverse[r], 3))
            return 0;
    for (int r = 0; r < 3; ++r) {
        for (int c = 0; c < 3; ++c) {
            double left = 0.0, right = 0.0;
            for (int k = 0; k < 3; ++k) {
                left += (double)matrix[r][k] * inverse[k][c];
                right += (double)inverse[r][k] * matrix[k][c];
            }
            const double expected = r == c ? 1.0 : 0.0;
            if (!isfinite(left) || !isfinite(right) ||
                fabs(left - expected) > 1.0e-3 ||
                fabs(right - expected) > 1.0e-3) return 0;
        }
    }
    return 1;
}

/* 3軸を全て検査してから結果を返す。異常時はresultを部分更新しない。
 * 浮動小数点のまま0..4095へ制限し、その後にuint16_tへ変換する。
 * applied_currentはDAC指令からの復元値であり、実測電流ではない。
 */
int Control_PrepareDac(const float requested_current[3], ControlDacCommand *result)
{
    if (result == NULL || !Control_AllFinite(requested_current, 3)) return -1;
    ControlDacCommand candidate = {{0, 0, 0}, {0.0f, 0.0f, 0.0f}, 0U};
    for (int axis = 0; axis < 3; ++axis) {
        const double offset = axis == 2 ? 1.5 : 0.99;
        const double span = axis == 2 ? 0.6 * 5.0 : 0.396 * 5.0;
        double code = ((double)requested_current[axis] + offset) * 4096.0 / span;
        if (!isfinite(code)) return -1;
        if (code < 0.0) {
            code = 0.0;
            candidate.saturated_mask |= 1U << axis;
        } else if (code > 4095.0) {
            code = 4095.0;
            candidate.saturated_mask |= 1U << axis;
        }
        candidate.code[axis] = (uint16_t)code;
        candidate.applied_current[axis] =
            (float)((double)candidate.code[axis] * span / 4096.0 - offset);
    }
    *result = candidate;
    return 0;
}

/* 最終的な加速度指令の絶対値・変化率を、指定された場合だけ制限する。 */
int Control_LimitAcceleration(float requested, float previous, float dt,
                             float max_acceleration, float max_jerk,
                             float *result, uint32_t *flags)
{
    if (result == NULL || flags == NULL || !isfinite(requested) ||
        !isfinite(previous) || !isfinite(dt) || dt <= 0.0f ||
        !isfinite(max_acceleration) || max_acceleration < 0.0f ||
        !isfinite(max_jerk) || max_jerk < 0.0f) return -1;
    double value = requested;
    uint32_t limited = 0U;
    if (max_acceleration > 0.0f) {
        if (value > max_acceleration) { value = max_acceleration; limited |= 1U; }
        if (value < -max_acceleration) { value = -max_acceleration; limited |= 1U; }
    }
    if (max_jerk > 0.0f) {
        const double step = (double)max_jerk * dt;
        const double lower = (double)previous - step;
        const double upper = (double)previous + step;
        if (value > upper) { value = upper; limited |= 2U; }
        if (value < lower) { value = lower; limited |= 2U; }
    }
    /* 実行中に上限を下げた場合も、加速度の絶対上限を優先する。 */
    if (max_acceleration > 0.0f) {
        if (value > max_acceleration) { value = max_acceleration; limited |= 5U; }
        if (value < -max_acceleration) { value = -max_acceleration; limited |= 5U; }
    }
    if (!isfinite(value)) return -1;
    *result = (float)value;
    *flags = limited;
    return 0;
}
