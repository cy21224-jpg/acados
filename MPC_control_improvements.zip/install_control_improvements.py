#!/usr/bin/env python3
"""Install only reviewed control files and the user's freshly generated solver.
Preflight everything, back up every destination, then replace files atomically.
Never write .ioc/.cproject/linker scripts/libraries/EKF/physical parameters.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import re
import sys

GENERATED = {
    'acados_solver_interaction_model.c': 'Core/Src/acados_generated/acados_solver_interaction_model.c',
    'interaction_model_model/interaction_model_expl_ode_fun.c': 'Core/Src/acados_generated/interaction_model_expl_ode_fun.c',
    'interaction_model_model/interaction_model_expl_vde_forw.c': 'Core/Src/acados_generated/interaction_model_expl_vde_forw.c',
    'interaction_model_model/interaction_model_expl_vde_adj.c': 'Core/Src/acados_generated/interaction_model_expl_vde_adj.c',
    'acados_solver_interaction_model.h': 'acados_model_generated/include/acados_solver_interaction_model.h',
    'interaction_model_model/interaction_model_model.h': 'acados_model_generated/include/interaction_model_model/interaction_model_model.h',
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def prepare(project, generated, package):
    if not (project / '.project').is_file():
        raise ValueError('STM32プロジェクトが見つかりません。')
    header = (generated / 'acados_solver_interaction_model.h').read_text()
    for name, expected in [('NX', 4), ('NU', 1), ('NP', 1), ('N', 5), ('NBX', 4), ('NBXN', 4)]:
        match = re.search(r'^#define\s+INTERACTION_MODEL_' + name + r'\s+(\d+)\s*$', header, re.M)
        if match is None or int(match.group(1)) != expected:
            raise ValueError('生成ヘッダーの次元が今回の修正版と一致しません: ' + name)
    solver = (generated / 'acados_solver_interaction_model.c').read_text()
    references = re.findall(r'\byref(?:_0)?\[4\]\s*=\s*([+\-\d.eE]+)\s*;', solver)
    if len(references) != 2 or any(float(value) != 1.0 for value in references):
        raise ValueError('生成Cの入力参照が全段1Nであることを確認できません。Pythonで再生成してください。')
    for name in ['acados', 'hpipm', 'blasfeo']:
        if not (project / 'acados_stm32_f767/lib' / ('lib' + name + '.a')).is_file():
            raise ValueError('既存STM32ライブラリが見つかりません: ' + name)
    jobs = []
    manifest = json.loads((package / 'install_manifest.json').read_text())
    for item in manifest:
        data = (package / item['source']).read_bytes()
        if sha(data) != item['sha256']:
            raise ValueError('配布ファイルの一致確認に失敗: ' + item['source'])
        jobs.append((item['destination'], data))
    for source, destination in GENERATED.items():
        jobs.append((destination, (generated / source).read_bytes()))
    for relative, _ in jobs:
        dst = project / relative
        if not dst.resolve().is_relative_to(project.resolve()) or dst.is_symlink():
            raise ValueError('追加先のパスを確認してください: ' + relative)
        if not dst.parent.is_dir():
            raise ValueError('追加先のフォルダーが見つかりません: ' + relative)
    return jobs

def install(project, generated, package, dry_run=False):
    jobs = prepare(project, generated, package)
    changed = [(rel, data) for rel, data in jobs
               if not (project / rel).is_file() or (project / rel).read_bytes() != data]
    print('MPC入力参照=1N、元の力目標=1N。対象:', len(jobs), 'ファイル、変更:', len(changed))
    if dry_run:
        for relative, _ in changed: print('予定:', relative)
        return
    if not changed:
        print('同じ内容が導入済みです。変更なし。')
        return
    protected_paths = [*project.glob('*.ioc'), project / '.cproject', *project.glob('*.ld'),
                       *project.glob('acados_stm32_f767/lib/*.a'),
                       project / 'Core/Src/function_3link.c', project / 'Core/Inc/function_3link.h',
                       project / 'Core/Src/param_3link.c', project / 'Core/Inc/param_3link.h']
    protected = {p: sha(p.read_bytes()) for p in protected_paths if p.is_file()}
    backup = project / '.control-backups' / datetime.now(timezone.utc).strftime('improvements_%Y%m%d_%H%M%S_%f')
    backup.mkdir(parents=True, exist_ok=False)
    originals = {}
    for relative, _ in changed:
        dst = project / relative
        originals[relative] = dst.read_bytes() if dst.is_file() else None
        if originals[relative] is not None:
            saved = backup / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(originals[relative])
    written = []
    try:
        for relative, data in changed:
            dst = project / relative
            temporary = dst.with_name(dst.name + '.control-new')
            if temporary.exists(): raise FileExistsError(temporary)
            try:
                temporary.write_bytes(data)
                os.replace(temporary, dst)
            finally:
                if temporary.exists(): temporary.unlink()
            written.append(relative)
            if dst.read_bytes() != data: raise IOError('一致確認失敗: ' + relative)
        if any(sha(p.read_bytes()) != digest for p, digest in protected.items()):
            raise RuntimeError('保護対象のファイルが変化しています。')
    except Exception:
        for relative in reversed(written):
            dst = project / relative
            if originals[relative] is None: dst.unlink()
            else: dst.write_bytes(originals[relative])
        raise
    record = {'files': [{'destination': rel, 'sha256': sha(data), 'existed': originals.get(rel) is not None}
                        for rel, data in changed]}
    (backup / 'install_record.json').write_text(json.dumps(record, ensure_ascii=False, indent=2))
    for relative, _ in changed: print('導入・一致確認OK:', relative)
    print('バックアップ:', backup)
    print('タイマー・クロック・.ioc・.cproject・リンカ・.a・EKF本体・慣性パラメータは変更していません。')
    print('CubeIDEでRefresh→Clean→Buildを実施してください。異常停止後の自動復帰はありません。')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('project', type=Path)
    parser.add_argument('--generated', type=Path, required=True)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    try:
        install(args.project.resolve(), args.generated.resolve(), Path(__file__).resolve().parent, args.dry_run)
    except Exception as error:
        sys.exit('導入中止: ' + str(error))
