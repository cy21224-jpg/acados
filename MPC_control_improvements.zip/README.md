# STM32制御処理の改善版と入力参照1Nの反映

最新のmain（X=0.35m、Y=0.25mから開始、Yランプ、負の速度帰還を反映済みの版）を基にした修正版です。MPCの入力参照と元の力制御の目標を両方1Nにする方針に合わせています。

## 導入内容

配布する制御ファイルは次の6つです。

* Core/Src/main.c
* Core/Src/MPC_function.c
* Core/Inc/MPC_function.h
* Core/Src/control_guard.c（追加）
* Core/Inc/control_guard.h（追加）
* Core/Inc/MPC_timing.h（既存と同じ計測補助）

古い生成ソルバは同梱していません。インストーラーは、ユーザーがPythonで生成した最新の6ファイルを同時にコピーします。入力参照が1N、NX=4、NU=1、NP=1、N=5、状態制約数4であることを確認してから書き込みます。新しいPython側の重み・制約・モデルは、その生成物をそのまま使用します。

## 変更した処理

1. 元の力制御のF_w_cmd[0]を3Nから1Nへ変更。
2. DAC変換値を浮動小数点のまま0〜4095に制限し、その後に整数化。負値・NaNの不正な整数変換を防止。
3. オブザーバへ、DACの飽和・量子化後の指令に対応する電流指令を渡す。これはDACコードからの復元値で、実測電流ではありません。既存DAC式に対応する範囲を使い、新しい機械固有の安全電流値は設定していません。
4. RTOBの入力をsignal_rtob1へ訂正し、全軸の今周期のトルクを計算し終えてから手先力へ変換。
5. ヤコビ行列の逆行列を1回だけ求め、検査後に転置してJ^-Tを作成。失敗・非有限値・大きな数値残差で処理を中止。
6. 質量が不正な場合にEKFや除算へ進まない。質量を任意の上限で丸める処理はありません。
7. EKFの非有限出力・負の共分散対角・生成制約を満たさないc/kを拒否し、前回受理した状態・共分散を保持。EKF本体の計算式は変更しません。
8. c/kの許容範囲はMPC初期化時に実際の生成ソルバから取得。予測中一定のc/kが範囲外なら、QPへ渡す前に-5で拒否。制約値をmainに重複して決め打ちしません。
9. 逆行列・力推定・最終指令などの数値異常時に、既存On_ServoピンをLOWとして停止を保持。再起動まで自動復帰しません。通常のQP失敗・EKF拒否では、有限な元の力制御へ戻る動作を維持。
10. usedフラグ、実際のY位置・姿勢角、第2関節角、detJ、Fhat、DAC飽和、DWT実行時間を記録。未実行周期に前回のvalid=1を残さない。

タイマー、クロック、割り込み優先順位、.ioc、.cproject、リンカ、既存.a、Jnを含む物理パラメータ、修正済みのfunction_3link.c/.hは書き換えません。N・刻み時間・Rなどもインストーラーでは編集せず、手元の新しい生成物をコピーします。

## WSLからの導入

ZIPをWindowsのDownloadsに保存します。CubeIDEでビルドやデバッグを停止し、Pythonを実行した「コード」フォルダーで次を実行します。

```bash
mpc_new="/mnt/c/Users/Yngsw0407/STM32CubeIDE/workspace_1.18.0/3linc_DRL_EKF_MPFC"
mpc_stage=$(mktemp -d /tmp/mpc-control.XXXXXX)

python3 -m zipfile -e \
  "/mnt/c/Users/Yngsw0407/Downloads/MPC_control_improvements.zip" \
  "$mpc_stage"

python3 "$mpc_stage/install_control_improvements.py" "$mpc_new" \
  --generated "$PWD/c_generated_code"
```

事前確認だけの場合は最後のコマンドへ `--dry-run` を付けます。全ファイルを事前検査し、変更する元ファイルを `.control-backups/improvements_...` へ保存します。書き込み中の例外では書き換えたファイルを戻します。同じ内容を再実行しても重複変更しません。

導入後はCubeIDEでプロジェクトをRefresh→Clean→Buildしてください。新しいcontrol_guard.cがビルド対象に入ったことも確認します。Linux用の.o/.soはコピーしません。

## 加速度上限・変化率上限

許容値の回答がまだないため、mainの次の値は両方0（制限無効）です。

```c
volatile float control_x_accel_limit = 0.0f; /* m/s^2、0=無効 */
volatile float control_x_jerk_limit = 0.0f;  /* m/s^3、0=無効 */
```

機械の許容値が分かってから正の値を設定してください。MPCと元の力制御が合流し、WOBを加算した後のX加速度指令へ適用します。飽和後のDAC範囲内に収まること自体は、機械固有の許容加速度・許容電流を満たす保証ではありません。今回はMPCの接触判定の閾値や出力の混合係数も変更していません。

## ログとデバッガ

| 値 | 意味 |
|---|---|
| used | 今回の周期でMPC出力を採用した場合1 |
| ekf=0 | EKF結果を受理した |
| ekf=-2 | 非有限値または共分散検査で拒否 |
| ekf/update/step=-5 | 推定c/kが生成制約の範囲外。QPは未実行 |
| step=-999 | 今周期は未実行 |
| a_ref | 元の制御またはMPCから選択した加速度指令 |
| a_out | WOB加算・任意の制限後、逆ヤコビへ渡したX指令 |
| y, phi, q2 | 実測計算したY位置、姿勢角、第2関節角（角度はrad） |
| detJ | L1*L2*sin(q2)。0へ近づくと特異姿勢を疑う |
| sat | DAC飽和軸のビットマスク。1=Xではなくモータ1、2=モータ2、4=モータ3 |
| solve_us | 今周期のMPC_Execute区間。未実行なら0 |
| ctrl_prev_us | 直前周期のTIM7内制御処理時間。printfも含む |
| max_us | 制御処理区間の最大計測値 |
| overrun | その区間が1ms以上だった周期数 |
| timing | DWT計測可能なら1。0のとき時間値は未計測 |

デバッガでは `control_requested_current[3]`、`control_applied_current[3]`、`control_current_saturated_count`、`control_ekf_rejected_count`、`control_fault_code`、`control_accel_limit_flags` も確認できます。

fault=1:角度/速度、2:逆行列、3:質量、4:力推定/DOB、5:加速度、6:電流指令、7:制限設定、8:HAL異常。故障後は `CONTROL STOP ...` を1回表示し、サーボOFF信号を保持します。実機での停止挙動は既存のドライバと機構の仕様に依存します。

## 検証と限界

* ARM向けコンパイル・リンク成功。既存のstatic補助関数宣言と_gettimeofdayの警告は残ります。
* ホストでAddressSanitizer/UBSan/float-cast-overflowを使い、DAC飽和、量子化、NaN時の部分更新防止、逆行列検査、EKF出力検査、任意の加速度・変化率制限を確認。
* ARM命令エミュレーションで、生成制約取得、c/kの範囲外拒否、6種類の質量で18回のMPC計算、全段質量更新、予測値を確認。
* ARM上の実際の制御コールバックについて、センサ・EKF出力・SPIを模擬し、正常MPC採用、QP失敗時の元制御への復帰、拒否EKFの非持ち越し、NaN時の停止保持、停止中のエンコーダ処理を確認。
* ARM試験の生成Cは、最後に提供された生成物の入力参照だけを1Nにした比較用fixtureです。ユーザーが今回生成した実ファイルは未受領なので、同一物の試験ではありません。そのため配布物へ含めず、インストール時に手元の生成物を読み込みます。
* 実機の閉ループ安定性と1ms完了は未確認です。DWT区間には割り込みへの遅延・入口/出口などの全オーバーヘッドまでは含まれません。
* 逆行列残差の検査だけでは、近特異姿勢への接近を止められません。今回のログで姿勢と質量の関係を確認し、作業領域の停止余裕を決める必要があります。
* 単に1Nへ下げても、接触相手がなければ力制御は動き続けます。許容加速度未設定のまま安定化済みとは判断しないでください。
