################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/acados_generated/acados_solver_interaction_model.c \
../Core/Src/acados_generated/interaction_model_expl_ode_fun.c \
../Core/Src/acados_generated/interaction_model_expl_vde_adj.c \
../Core/Src/acados_generated/interaction_model_expl_vde_forw.c 

OBJS += \
./Core/Src/acados_generated/acados_solver_interaction_model.o \
./Core/Src/acados_generated/interaction_model_expl_ode_fun.o \
./Core/Src/acados_generated/interaction_model_expl_vde_adj.o \
./Core/Src/acados_generated/interaction_model_expl_vde_forw.o 

C_DEPS += \
./Core/Src/acados_generated/acados_solver_interaction_model.d \
./Core/Src/acados_generated/interaction_model_expl_ode_fun.d \
./Core/Src/acados_generated/interaction_model_expl_vde_adj.d \
./Core/Src/acados_generated/interaction_model_expl_vde_forw.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/acados_generated/%.o Core/Src/acados_generated/%.su Core/Src/acados_generated/%.cyclo: ../Core/Src/acados_generated/%.c Core/Src/acados_generated/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m7 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F767xx -c -I../Core/Inc -I"C:/Users/Yngsw0407/STM32CubeIDE/workspace_1.18.0/acadosdayo/acados_stm32_f767/include" -I"C:/Users/Yngsw0407/STM32CubeIDE/workspace_1.18.0/acadosdayo/acados_stm32_f767/include/blasfeo/include" -I"C:/Users/Yngsw0407/STM32CubeIDE/workspace_1.18.0/acadosdayo/acados_stm32_f767/include/hpipm/include" -I"C:/Users/Yngsw0407/STM32CubeIDE/workspace_1.18.0/acadosdayo/acados_model_generated/include" -I../Drivers/STM32F7xx_HAL_Driver/Inc -I../Drivers/STM32F7xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F7xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src-2f-acados_generated

clean-Core-2f-Src-2f-acados_generated:
	-$(RM) ./Core/Src/acados_generated/acados_solver_interaction_model.cyclo ./Core/Src/acados_generated/acados_solver_interaction_model.d ./Core/Src/acados_generated/acados_solver_interaction_model.o ./Core/Src/acados_generated/acados_solver_interaction_model.su ./Core/Src/acados_generated/interaction_model_expl_ode_fun.cyclo ./Core/Src/acados_generated/interaction_model_expl_ode_fun.d ./Core/Src/acados_generated/interaction_model_expl_ode_fun.o ./Core/Src/acados_generated/interaction_model_expl_ode_fun.su ./Core/Src/acados_generated/interaction_model_expl_vde_adj.cyclo ./Core/Src/acados_generated/interaction_model_expl_vde_adj.d ./Core/Src/acados_generated/interaction_model_expl_vde_adj.o ./Core/Src/acados_generated/interaction_model_expl_vde_adj.su ./Core/Src/acados_generated/interaction_model_expl_vde_forw.cyclo ./Core/Src/acados_generated/interaction_model_expl_vde_forw.d ./Core/Src/acados_generated/interaction_model_expl_vde_forw.o ./Core/Src/acados_generated/interaction_model_expl_vde_forw.su

.PHONY: clean-Core-2f-Src-2f-acados_generated

