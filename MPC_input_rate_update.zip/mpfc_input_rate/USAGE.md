# MPC入力変化率コスト用アダプタの初回導入

このフォルダーはSTM32CubeIDEのプロジェクトへコピーせず、WSL上の作業用フォルダーへ展開してください。まず確認だけ実行します。

```bash
python3 mpfc_input_rate/install_rate_cost.py "$dst" --check
python3 mpfc_input_rate/install_rate_cost.py "$dst"
```

`$dst`は既存のSTM32CubeIDEプロジェクトのパスです。変更対象は`MPC_function.c/.h`、`MPC_param.c/.h`と、`main.c`のMPC適用通知2箇所だけです。`.ioc`、タイマー設定、生成ソルバはこの導入では更新しません。変更前のファイルはプロジェクトの外側の`.mpc-rate-backups`へ保存します。既に導入済みなら変更しません。

添付元から独自に変更したMPCの4ファイルは上書きせず、比較・統合が必要であることを表示します。`main.c`は2箇所だけを照合し、それ以外の編集と改行コードを保持します。

この後で同梱のMPC用PythonからCを再生成し、更新版`update_acados.py`で生成物を更新してください。初回導入だけでは実機上の目的関数は切り替わりません。CubeIDEでRefresh → Clean → Buildし、実機へ書き込んでください。
