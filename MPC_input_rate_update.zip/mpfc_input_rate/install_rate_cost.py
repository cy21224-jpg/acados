#!/usr/bin/env python3
"""Install the MPC rate-cost adapter and two narrow main.c notification hooks.

Only the four manifest-listed MPC files may be replaced. Their current content
must equal the supplied baseline or the new payload. main.c is patched by two
exact snippets; unrelated bytes and line endings are retained.
"""

from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile


MPC_FILES = (
    "Core/Src/MPC_function.c",
    "Core/Inc/MPC_function.h",
    "Core/Src/MPC_param.c",
    "Core/Inc/MPC_param.h",
)
MAIN_FILE = "Core/Src/main.c"


class InstallError(RuntimeError):
    """An install precondition failed or an install was rolled back."""


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _target(project: Path, relative: str) -> Path:
    target = project / relative
    current = target
    while current != project:
        if current.is_symlink():
            raise InstallError(f"リンク先の更新は行いません: {relative}")
        current = current.parent
    if not target.is_file() or not target.resolve().is_relative_to(project):
        raise InstallError(f"更新先ファイルを確認してください: {relative}")
    return target


def _hook_variants(before: str, after: str) -> list[tuple[bytes, bytes]]:
    variants = []
    for newline in ("\r\n", "\n"):
        old = before.replace("\r\n", "\n").replace("\n", newline).encode("utf-8")
        new = after.replace("\r\n", "\n").replace("\n", newline).encode("utf-8")
        if (old, new) not in variants:
            variants.append((old, new))
    return variants


def patch_main(content: bytes, hooks: list[dict]) -> bytes:
    result = content
    for hook in hooks:
        candidates = _hook_variants(hook["before"], hook["after"])
        old_matches = [(old, new) for old, new in candidates if old in result]
        new_matches = [(old, new) for old, new in candidates if new in result]
        if not old_matches and len(new_matches) == 1:
            if result.count(new_matches[0][1]) != 1:
                raise InstallError(f"main.cの適用済み箇所が複数あります: {hook['name']}")
            continue
        if len(old_matches) != 1 or new_matches:
            raise InstallError(
                f"main.cのMPC適用箇所を一意に確認できません: {hook['name']}。"
                "main.c全体は上書きしません。対象箇所を手動で比較してください。"
            )
        old, new = old_matches[0]
        if result.count(old) != 1:
            raise InstallError(f"main.cの更新箇所が複数あります: {hook['name']}")
        result = result.replace(old, new, 1)
    return result


def make_plan(project: Path, package: Path) -> list[tuple[str, bytes, bytes]]:
    if not (project / ".project").is_file():
        raise InstallError(f"STM32CubeIDEプロジェクトが見つかりません: {project}")
    manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
    entries = manifest.get("files", {})
    if set(entries) != set(MPC_FILES):
        raise InstallError("パッケージのMPCファイル一覧が不正です")
    plan = []
    for relative in MPC_FILES:
        target = _target(project, relative)
        old = target.read_bytes()
        new = (package / "stm32" / relative).read_bytes()
        spec = entries[relative]
        if sha256(new) != spec["installed_sha256"]:
            raise InstallError(f"パッケージ内のファイルが一致しません: {relative}")
        if sha256(old) not in (spec["original_sha256"], spec["installed_sha256"]):
            raise InstallError(
                f"独自の変更を検出したため更新しません: {relative}。"
                "添付元または本パッケージと一致する場合だけ置換します。"
                "現在の変更を比較・統合してください。"
            )
        if old != new:
            plan.append((relative, old, new))
    hooks = json.loads((package / "main_hooks.json").read_text(encoding="utf-8"))
    if not isinstance(hooks, list) or len(hooks) != 2:
        raise InstallError("パッケージのmain.c通知箇所が不正です")
    main = _target(project, MAIN_FILE).read_bytes()
    patched = patch_main(main, hooks)
    if patched != main:
        plan.append((MAIN_FILE, main, patched))
    return plan


def _write_atomic(target: Path, content: bytes) -> None:
    """Replace one file without exposing a partially written C source."""
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".mpc-rate-", dir=target.parent, delete=False) as output:
            temporary = Path(output.name)
            os.chmod(temporary, stat.S_IMODE(target.stat().st_mode))
            output.write(content)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, target)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def install(project: Path, *, check: bool = False, package: Path | None = None) -> dict:
    project = project.expanduser().resolve(strict=True)
    package = (package or Path(__file__).resolve().parent).resolve(strict=True)
    plan = make_plan(project, package)
    for relative, _old, _new in plan:
        print("変更予定:" if check else "変更あり:", relative)
    if check:
        print(f"確認のみ: {len(plan)}ファイル。書き込み・バックアップ作成はしていません。")
        return {"changed": [entry[0] for entry in plan], "backup": None}
    if not plan:
        print("導入済みです。変更なし。")
        return {"changed": [], "backup": None}

    # Keep backups outside the project so CubeIDE cannot compile backup .c files.
    backup = project.parent / ".mpc-rate-backups" / (
        project.name + "_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    )
    if backup.resolve().is_relative_to(project):
        raise InstallError("バックアップ先がプロジェクト内にあります")
    for relative, old, _new in plan:
        if _target(project, relative).read_bytes() != old:
            raise InstallError(f"確認後にファイルが変更されました: {relative}")
    backup.mkdir(parents=True)
    for relative, _old, _new in plan:
        saved = backup / relative
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(project / relative, saved)

    written = []
    try:
        for relative, old, new in plan:
            target = _target(project, relative)
            if target.read_bytes() != old:
                raise InstallError(f"更新中に別の変更を検出しました: {relative}")
            _write_atomic(target, new)
            written.append(relative)
            if target.read_bytes() != new:
                raise InstallError(f"コピー後に不一致を検出しました: {relative}")
    except Exception as error:
        rollback_errors = []
        for relative in reversed(written):
            try:
                shutil.copy2(backup / relative, project / relative)
            except Exception as rollback_error:
                rollback_errors.append(f"{relative}: {rollback_error}")
        if rollback_errors:
            raise InstallError(
                f"更新失敗: {error}。復元できなかったファイル: {'; '.join(rollback_errors)}。"
                f"バックアップ: {backup}"
            ) from error
        raise InstallError(f"更新失敗。書き換えたファイルは復元しました: {error}。バックアップ: {backup}") from error

    print(f"導入完了: {len(plan)}ファイル。main.cはMPC適用通知の2箇所だけ変更しました。")
    print("バックアップ:", backup)
    print("続いてPythonから生成し、update_acados.pyで生成物を更新してください。")
    return {"changed": [entry[0] for entry in plan], "backup": str(backup)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path, help="STM32CubeIDEプロジェクトのパス")
    parser.add_argument("--check", action="store_true", help="確認のみ。ファイルに書き込みません")
    args = parser.parse_args(argv)
    try:
        install(args.project, check=args.check)
    except (InstallError, OSError, ValueError, KeyError, TypeError) as error:
        print(f"導入中止: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
