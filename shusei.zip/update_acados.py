#!/usr/bin/env python3
"""Sync only interaction_model generated C/H into the STM32 project.

Usage is unchanged:
    python3 update_acados.py c_generated_code STM32_PROJECT --check
    python3 update_acados.py c_generated_code STM32_PROJECT

The check mode does not write anything. Normal updates back up changed files
outside the project, atomically replace individual files and roll back a
partially committed update on failure. main/EKF/.ioc/.cproject/libraries are
never installation targets. Install the matching MPC adapter separately once
when changing its state/parameter interface.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile


MODEL = "interaction_model"
SOURCE_DIR = Path("Core/Src/acados_generated")
INCLUDE_DIR = Path("acados_model_generated/include")
SOLVER_C = f"acados_solver_{MODEL}.c"
SOLVER_H = f"acados_solver_{MODEL}.h"
INCLUDE_RE = re.compile(r'^\s*#\s*include\s+"([^"]+)"', re.M)
SDK_PREFIXES = ("acados/", "acados_c/", "blasfeo/", "hpipm/", "blasfeo_", "hpipm_")
STANDARD_HEADERS = {"math.h", "stdlib.h", "stdio.h", "string.h", "stddef.h", "stdint.h", "stdbool.h", "assert.h"}


class UpdateError(RuntimeError):
    """An incomplete or incompatible update that must not be installed."""


@dataclass
class Plan:
    source_root: Path
    project_root: Path
    # Project-relative target -> exact source bytes.
    data: dict[Path, bytes]
    before: dict[Path, bytes | None]
    sources: dict[Path, bytes]
    dimensions: dict[str, int]
    orphan_candidates: list[Path]

    @property
    def changed(self) -> list[Path]:
        return [p for p in self.data if self.before[p] != self.data[p]]


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _regular_path(root: Path, relative: Path, *, required: bool = False) -> Path:
    if relative.is_absolute() or ".." in relative.parts:
        raise UpdateError(f"不正なパス: {relative}")
    p = root / relative
    cursor = p
    while cursor != root:
        if cursor.is_symlink():
            raise UpdateError(f"シンボリックリンクは更新対象にできません: {p}")
        cursor = cursor.parent
    if not _inside(p, root):
        raise UpdateError(f"対象フォルダの外を参照しています: {p}")
    if p.exists() and not p.is_file():
        raise UpdateError(f"通常ファイルではありません: {p}")
    if required and not p.is_file():
        raise UpdateError(f"必要なファイルがありません: {p}")
    return p


def _macro(text: str, name: str) -> int | None:
    m = re.search(rf"^\s*#define\s+{re.escape(name)}\s+\(?\s*(\d+)\s*\)?\s*(?://[^\n]*|/\*[^\n]*\*/)?\s*$", text, re.M)
    return int(m.group(1)) if m else None


def _generated_family(name: str) -> bool:
    return name.startswith(MODEL + "_") and Path(name).suffix in {".c", ".h"}


def prepare_update(source: Path | str, project: Path | str) -> Plan:
    source = Path(source).expanduser().resolve()
    project = Path(project).expanduser().resolve()
    if not source.is_dir():
        raise UpdateError(f"生成元フォルダがありません: {source}")
    if not (project / ".project").is_file():
        raise UpdateError(f"STM32プロジェクトがありません: {project}")
    if source == project or _inside(project, source):
        raise UpdateError("生成元とSTM32プロジェクトは別フォルダを指定してください")

    sources: dict[Path, bytes] = {}
    for name in [SOLVER_C, SOLVER_H, f"{MODEL}_model/{MODEL}_model.h"]:
        relative = Path(name)
        sources[relative] = _regular_path(source, relative, required=True).read_bytes()
    for p in sorted(source.iterdir()):
        if p.is_file() and _generated_family(p.name):
            relative = p.relative_to(source)
            sources[relative] = _regular_path(source, relative, required=True).read_bytes()
    for suffix in ["model", "cost", "constraints"]:
        directory = source / f"{MODEL}_{suffix}"
        if directory.is_symlink():
            raise UpdateError(f"生成ディレクトリがシンボリックリンクです: {directory}")
        if not directory.exists():
            continue
        if not directory.is_dir():
            raise UpdateError(f"生成ディレクトリを確認してください: {directory}")
        for p in sorted(directory.iterdir()):
            if _generated_family(p.name):
                relative = p.relative_to(source)
                sources[relative] = _regular_path(source, relative, required=True).read_bytes()
    if not any(p.parent == Path(f"{MODEL}_model") and p.suffix == ".c" for p in sources):
        raise UpdateError("モデルの生成Cファイルがありません")

    header = sources[Path(SOLVER_H)].decode("utf-8-sig")
    dimensions = {}
    for key in ["NX", "NU", "NP", "N"]:
        value = _macro(header, f"{MODEL.upper()}_{key}")
        if value is None or value < (0 if key == "NP" else 1):
            raise UpdateError(f"生成ヘッダーの{key}が確認できません")
        dimensions[key] = value
    runtime = project / "Core/Inc/MPC_param.h"
    if runtime.is_file():
        runtime_text = _regular_path(project, Path("Core/Inc/MPC_param.h"), required=True).read_text(encoding="utf-8-sig")
        for source_key, runtime_key in [("NX", "MPC_STATE_DIM"), ("NU", "MPC_INPUT_DIM")]:
            expected = _macro(runtime_text, runtime_key)
            if expected is not None and expected != dimensions[source_key]:
                raise UpdateError(f"{source_key}={dimensions[source_key]}とSTM32側{runtime_key}={expected}が不一致です。先に対応するMPCアダプタを配置してください")
    adapter = project / "Core/Src/MPC_function.c"
    if adapter.is_file():
        adapter_text = _regular_path(project, Path("Core/Src/MPC_function.c"), required=True).read_text(encoding="utf-8-sig")
        expected_np = re.findall(r"INTERACTION_MODEL_NP\s*==\s*(\d+)", adapter_text)
        if expected_np and any(int(n) != dimensions["NP"] for n in expected_np):
            raise UpdateError(f"NP={dimensions['NP']}がSTM32側MPCアダプタの実行時パラメータ数と異なります")

    data: dict[Path, bytes] = {}
    source_for_target: dict[Path, Path] = {}
    for relative, content in sources.items():
        target = SOURCE_DIR / relative.name if relative.suffix == ".c" else INCLUDE_DIR / relative
        if target in source_for_target and source_for_target[target] != relative:
            raise UpdateError(f"生成Cのファイル名が重複しています: {relative.name}")
        source_for_target[target] = relative
        data[target] = content

    # Resolve generated include dependencies before creating any directories.
    # A module-local header included by a flattened C file also needs a root
    # include alias. This avoids rewriting generated C and keeps byte equality.
    for relative, content in sources.items():
        text = content.decode("utf-8-sig")
        for name in INCLUDE_RE.findall(text):
            include = Path(name)
            if include.is_absolute() or ".." in include.parts:
                raise UpdateError(f"生成コードに不正なincludeがあります: {relative}: {name}")
            resolved = include if include in sources else relative.parent / include
            if resolved in sources:
                if relative.suffix == ".c" and len(include.parts) == 1 and resolved.parent != Path("."):
                    alias = INCLUDE_DIR / include.name
                    if alias in data and data[alias] != sources[resolved]:
                        raise UpdateError(f"生成ヘッダー名が衝突しています: {include.name}")
                    data[alias] = sources[resolved]
                continue
            if name.startswith(SDK_PREFIXES) or name in STANDARD_HEADERS:
                continue
            raise UpdateError(f"生成コードが必要とするヘッダーがありません: {relative}: {name}")

    # Acados module headers declare each emitted CasADi callback. Detect a
    # missing .c even when the top-level solver only includes the module .h.
    for relative, content in sources.items():
        if relative.suffix != ".h" or relative == Path(SOLVER_H):
            continue
        declared = re.findall(rf"\bint\s+({MODEL}_[A-Za-z0-9_]+)\s*\(", content.decode("utf-8-sig"))
        for symbol in declared:
            if symbol.endswith(("_work", "_work_bytes", "_sparsity_in", "_sparsity_out", "_n_in", "_n_out", "_alloc_mem", "_init_mem", "_checkout")):
                continue
            if not any(p.name == symbol + ".c" for p in sources):
                raise UpdateError(f"生成関数のCがありません: {symbol}.c（宣言: {relative}）")

    before = {}
    for relative in data:
        path = _regular_path(project, relative)
        before[relative] = path.read_bytes() if path.is_file() else None
    orphans = []
    existing_source = project / SOURCE_DIR
    if existing_source.is_dir():
        orphans.extend(p.relative_to(project) for p in existing_source.iterdir()
                       if p.is_file() and _generated_family(p.name) and p.relative_to(project) not in data)
    for suffix in ["model", "cost", "constraints"]:
        directory = project / INCLUDE_DIR / f"{MODEL}_{suffix}"
        if directory.is_dir():
            orphans.extend(p.relative_to(project) for p in directory.iterdir()
                           if p.is_file() and _generated_family(p.name) and p.relative_to(project) not in data)
    return Plan(source, project, data, before, sources, dimensions, sorted(orphans))


def _write_temp(path: Path, content: bytes, mode: int | None) -> Path:
    handle, name = tempfile.mkstemp(prefix=f".{path.name}.mpc-", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(handle, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        if mode is not None:
            os.chmod(temporary, mode)
        if temporary.read_bytes() != content:
            raise IOError(f"一時ファイルの一致確認に失敗: {path}")
        return temporary
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def _replace(path: Path, content: bytes, mode: int | None = None) -> None:
    temporary = _write_temp(path, content, mode)
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def apply_update(plan: Plan) -> Path | None:
    changed = plan.changed
    if not changed:
        return None
    project = plan.project_root
    backup_parent = project.parent / f".{project.name}.mpc-backups"
    if backup_parent.is_symlink() or (backup_parent.exists() and not backup_parent.is_dir()):
        raise UpdateError(f"バックアップ先を確認してください: {backup_parent}")
    backup = backup_parent / datetime.now().strftime("generated_%Y%m%d_%H%M%S_%f")
    backup.mkdir(parents=True)
    modes = {}
    record = {"project": str(project), "source": str(plan.source_root), "files": {}}
    for relative in changed:
        target = _regular_path(project, relative)
        modes[relative] = stat.S_IMODE(target.stat().st_mode) if target.exists() else None
        old = plan.before[relative]
        if old is not None:
            saved = backup / relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(old)
            if saved.read_bytes() != old:
                raise UpdateError(f"バックアップ一致確認に失敗: {relative}")
        record["files"][str(relative)] = {
            "existed": old is not None,
            "before_sha256": hashlib.sha256(old).hexdigest() if old is not None else None,
            "after_sha256": hashlib.sha256(plan.data[relative]).hexdigest(),
        }
    (backup / "record.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    staged: dict[Path, Path] = {}
    committed: list[Path] = []
    created_directories: list[Path] = []
    completed = False
    try:
        # Abort if generation or the destination changed while the plan was read.
        for relative, content in plan.sources.items():
            if _regular_path(plan.source_root, relative, required=True).read_bytes() != content:
                raise UpdateError(f"処理中に生成元が変わりました: {relative}")
        for relative in changed:
            target = _regular_path(project, relative)
            current = target.read_bytes() if target.exists() else None
            if current != plan.before[relative]:
                raise UpdateError(f"処理中に更新先が変わりました: {relative}")
            missing = []
            directory = target.parent
            while not directory.exists():
                missing.append(directory)
                directory = directory.parent
            for directory in reversed(missing):
                directory.mkdir()
                created_directories.append(directory)
            staged[relative] = _write_temp(target, plan.data[relative], modes[relative])
        for relative in changed:
            target = _regular_path(project, relative)
            os.replace(staged[relative], target)
            committed.append(relative)
            if target.read_bytes() != plan.data[relative]:
                raise IOError(f"コピー後の不一致: {relative}")
        completed = True
    except BaseException as error:
        rollback_errors = []
        for relative in reversed(committed):
            try:
                target = project / relative
                old = plan.before[relative]
                if old is None:
                    target.unlink()
                else:
                    _replace(target, old, modes[relative])
            except BaseException as restore_error:
                rollback_errors.append(f"{relative}: {restore_error}")
        if rollback_errors:
            raise UpdateError(f"更新失敗: {error}。復元にも失敗: {'; '.join(rollback_errors)}。バックアップ: {backup}") from error
        raise UpdateError(f"更新失敗のため変更を復元しました: {error}。バックアップ: {backup}") from error
    finally:
        for temporary in staged.values():
            temporary.unlink(missing_ok=True)
        if not completed:
            for directory in reversed(created_directories):
                try:
                    directory.rmdir()
                except OSError:
                    pass
    return backup


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("project", type=Path)
    parser.add_argument("--check", action="store_true", help="差分確認だけ。書き込み・バックアップ作成なし")
    args = parser.parse_args(argv)
    try:
        plan = prepare_update(args.source, args.project)
        print("モデル次元:", ", ".join(f"{k}={v}" for k, v in plan.dimensions.items()))
        for target in plan.data:
            print("変更あり:" if target in plan.changed else "一致:", target)
        if plan.orphan_candidates:
            print("更新対象外の旧生成候補は保持します:")
            for target in plan.orphan_candidates:
                print("  ", target)
        if args.check:
            print("確認のみ。書き込みはしていません。")
            return 0
        backup = apply_update(plan)
        if backup is None:
            print("すべて同じ内容です。変更なし。")
        else:
            for target in plan.changed:
                print("更新・一致確認OK:", target)
            print(f"更新完了: {len(plan.changed)}ファイル")
            print("バックアップ:", backup)
            print("CubeIDEでRefresh → Clean → Build → 実機へ書き込み")
        return 0
    except (OSError, UnicodeError, UpdateError) as error:
        print(f"更新中止: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
