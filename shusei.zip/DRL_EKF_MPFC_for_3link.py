"""Compatibility entry for the documented WSL regeneration command.

The model is implemented in DRL_EKF_MPFC_for_3link2.py so both entry names
always generate the same three-state solver.
"""
from DRL_EKF_MPFC_for_3link2 import DRL_EKF_func_series, main


if __name__ == "__main__":
    main()
