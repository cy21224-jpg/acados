/**
 * @file MPC_function.c
 * @brief 3状態[v, x, k]の生成ソルバと、DWTによる任意の計時を扱う。
 *
 * 別の生成モデルへ移す場合は、以下の生成ヘッダ・シンボル名と次元確認を更新する。
 * 作業領域は初期化時に作成し、計算ループ中にカプセルを作り直さない。
 */
#include "MPC_function.h"
#include "acados_solver_interaction_model.h"
#include <math.h>
#include <stddef.h>

_Static_assert(MPC_STATE_DIM == 3 && MPC_INPUT_DIM == 1 &&
               INTERACTION_MODEL_NX == MPC_STATE_DIM &&
               INTERACTION_MODEL_NU == MPC_INPUT_DIM &&
               INTERACTION_MODEL_NBX0 == MPC_STATE_DIM &&
               INTERACTION_MODEL_NBU == MPC_INPUT_DIM &&
               INTERACTION_MODEL_N >= 1,
               "Update MPC adapter for the generated model dimensions");

/* NP=0の旧生成ファイルとの混在をビルド時に検出する。 */
_Static_assert(INTERACTION_MODEL_NP == 1,
               "Regenerate the solver with model.p = [equivalent_mass]");

/* 起動時に作成したソルバと入出力を保持し、毎回のメモリ確保を避ける。 */
static interaction_model_solver_capsule *mpc_capsule = NULL;
static ocp_nlp_config *mpc_config = NULL;
static ocp_nlp_dims *mpc_dims = NULL;
static ocp_nlp_in *mpc_in = NULL;
static ocp_nlp_out *mpc_out = NULL;
static ocp_nlp_solver *mpc_solver = NULL;
static int mpc_state_pending = 0;
/* Linux版と同様、前回成功時の入力列を次回の初期推定に使う。 */
static int mpc_has_warm_start = 0;
static double mpc_previous_u[INTERACTION_MODEL_N];

/* Stiffness is constant during each horizon. Read its admissible range
 * from generated state bounds instead of duplicating Python values here. */
_Static_assert(INTERACTION_MODEL_NBX <= MPC_STATE_DIM &&
               INTERACTION_MODEL_NBXN <= MPC_STATE_DIM,
               "Unexpected generated state-bound dimensions");
static double mpc_stiffness_lower;
static double mpc_stiffness_upper;
static double mpc_stage_input_lower[INTERACTION_MODEL_N];
static double mpc_stage_input_upper[INTERACTION_MODEL_N];

static int MPC_ReadParameterBounds(void)
{
    mpc_stiffness_lower = -INFINITY;
    mpc_stiffness_upper = INFINITY;
    for (int stage = 1; stage <= INTERACTION_MODEL_N; ++stage) {
        const int count = stage == INTERACTION_MODEL_N
                          ? INTERACTION_MODEL_NBXN : INTERACTION_MODEL_NBX;
        int indices[MPC_STATE_DIM];
        double lower[MPC_STATE_DIM], upper[MPC_STATE_DIM];
        if (count == 0) continue;
        ocp_nlp_constraints_model_get(mpc_config, mpc_dims, mpc_in, stage, "idxbx", indices);
        ocp_nlp_constraints_model_get(mpc_config, mpc_dims, mpc_in, stage, "lbx", lower);
        ocp_nlp_constraints_model_get(mpc_config, mpc_dims, mpc_in, stage, "ubx", upper);
        for (int bound = 0; bound < count; ++bound) {
            if (indices[bound] < 0 || indices[bound] >= MPC_STATE_DIM ||
                isnan(lower[bound]) || isnan(upper[bound]) ||
                lower[bound] > upper[bound]) return -3;
            if (indices[bound] == 2) {
                mpc_stiffness_lower = fmax(mpc_stiffness_lower, lower[bound]);
                mpc_stiffness_upper = fmin(mpc_stiffness_upper, upper[bound]);
            }
        }
    }
    return mpc_stiffness_lower <= mpc_stiffness_upper ? 0 : -3;
}

static int MPC_ReadInputBounds(void)
{
    for (int stage = 0; stage < INTERACTION_MODEL_N; ++stage) {
        int index;
        double lower, upper;
        ocp_nlp_constraints_model_get(mpc_config, mpc_dims, mpc_in, stage, "idxbu", &index);
        ocp_nlp_constraints_model_get(mpc_config, mpc_dims, mpc_in, stage, "lbu", &lower);
        ocp_nlp_constraints_model_get(mpc_config, mpc_dims, mpc_in, stage, "ubu", &upper);
        if (index != 0 || !isfinite(lower) || !isfinite(upper) || lower > upper)
            return -3;
        mpc_stage_input_lower[stage] = lower;
        mpc_stage_input_upper[stage] = upper;
    }
    mpc_input_lower = mpc_stage_input_lower[0];
    mpc_input_upper = mpc_stage_input_upper[0];
    return 0;
}

int MPC_ValidateEstimatedState(const double state[MPC_STATE_DIM])
{
    if (mpc_create_status != 0 || mpc_capsule == NULL) return -1;
    if (state == NULL) return -2;
    for (int n = 0; n < MPC_STATE_DIM; ++n)
        if (!isfinite(state[n])) return -2;
    return state[2] >= mpc_stiffness_lower && state[2] <= mpc_stiffness_upper
           ? 0 : -5;
}

static void MPC_PrepareWarmStart(void);

/* DWT is an optional clock source; numerical MPC code remains host-testable. */
#if !defined(MPC_TIMING_PORTABLE)
#include "stm32f7xx.h"
#endif

static MPC_TickProvider mpc_tick_provider = NULL;
static MPC_TickProvider mpc_counter_provider = NULL;
static uint32_t mpc_task_start_counter = 0U;
static int mpc_task_timing_active = 0;

static uint32_t MPC_TimingNow(void)
{
    return mpc_counter_provider != NULL ? mpc_counter_provider() : 0U;
}

static uint32_t MPC_TimingToUs(uint64_t ticks, uint32_t hz)
{
    const uint64_t us = ticks * 1000000ULL / hz;
    return us > UINT32_MAX ? UINT32_MAX : (uint32_t)us;
}

void MPC_ResetTimingStats(void)
{
    const MPC_TimingStats empty = {
        .last_us = UINT32_MAX, .last_seconds = NAN, .last_status = -999
    };
    mpc_timing_sequence++;
    mpc_solver_timing = empty;
    mpc_execute_timing = empty;
    mpc_task_timing = empty;
    mpc_solve_time_ms = UINT32_MAX;
    mpc_solve_time_us = UINT32_MAX;
    mpc_solve_time_s = NAN;
    mpc_task_timing_active = 0;
    mpc_timing_sequence++;
}

int MPC_SetTimingProvider(MPC_TickProvider provider, uint32_t counter_hz)
{
    if (provider == NULL || counter_hz == 0U) return -1;
    mpc_counter_provider = provider;
    mpc_timing_clock_hz = counter_hz;
    mpc_timing_source = 2;
    mpc_timing_ready = 1;
    MPC_ResetTimingStats();
    return 0;
}

void MPC_SetTickProvider(MPC_TickProvider provider)
{
    mpc_tick_provider = provider;
    /* Replacing a legacy source cannot leave an old provider marked ready. */
    if (mpc_timing_source == 3) {
        mpc_counter_provider = provider;
        mpc_timing_clock_hz = provider != NULL ? 1000U : 0U;
        mpc_timing_ready = provider != NULL;
        mpc_timing_source = provider != NULL ? 3 : 0;
        MPC_ResetTimingStats();
    }
}

#if !defined(MPC_TIMING_PORTABLE)
static uint32_t MPC_ReadDwtCounter(void)
{
    return DWT->CYCCNT;
}
#endif

int MPC_TimingInit(void)
{
    if (mpc_counter_provider != NULL && mpc_timing_clock_hz != 0U &&
        mpc_timing_ready) return 0;
#if !defined(MPC_TIMING_PORTABLE)
    if (SystemCoreClock != 0U &&
        (DWT->CTRL & DWT_CTRL_NOCYCCNT_Msk) == 0U) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
        DWT->LAR = 0xC5ACCE55UL;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
        /* Do not reset CYCCNT or any timer/clock/interrupt configuration. */
        __DSB();
        __ISB();
        const uint32_t before = DWT->CYCCNT;
        for (volatile uint32_t n = 0U; n < 32U; ++n) __NOP();
        if (DWT->CYCCNT != before) {
            mpc_counter_provider = MPC_ReadDwtCounter;
            mpc_timing_clock_hz = SystemCoreClock;
            mpc_timing_source = 1;
            mpc_timing_ready = 1;
            return 0;
        }
    }
#endif
    if (mpc_tick_provider != NULL) {
        mpc_counter_provider = mpc_tick_provider;
        mpc_timing_clock_hz = 1000U;
        mpc_timing_source = 3;
        mpc_timing_ready = 1;
        return 0;
    }
    mpc_timing_ready = 0;
    mpc_timing_source = 0;
    mpc_timing_clock_hz = 0U;
    return -1;
}

static void MPC_RecordTiming(volatile MPC_TimingStats *record,
                             uint32_t start_counter, int status)
{
    if (!mpc_timing_ready || mpc_timing_clock_hz == 0U ||
        mpc_counter_provider == NULL || record->samples == UINT32_MAX) return;
    const uint32_t elapsed = MPC_TimingNow() - start_counter;
    const uint32_t hz = mpc_timing_clock_hz;
    mpc_timing_sequence++;
    record->last_counter_ticks = elapsed;
    record->last_us = MPC_TimingToUs(elapsed, hz);
    record->last_seconds = (double)elapsed / (double)hz;
    if (record->samples == 0U || elapsed > record->max_counter_ticks) {
        record->max_counter_ticks = elapsed;
        record->max_us = record->last_us;
    }
    record->samples++;
    record->total_counter_ticks += elapsed;
    record->mean_us = MPC_TimingToUs(
        record->total_counter_ticks / record->samples, hz);
    if ((uint64_t)elapsed * 1000000ULL > (uint64_t)hz * 10000ULL)
        record->over_10ms++;
    record->last_status = status;
    mpc_timing_sequence++;
}

void MPC_TaskTimingStart(void)
{
    mpc_task_start_counter = MPC_TimingNow();
    mpc_task_timing_active = 1;
}

void MPC_TaskTimingStop(void)
{
    if (mpc_task_timing_active) {
        MPC_RecordTiming(&mpc_task_timing, mpc_task_start_counter, mpc_step_status);
        mpc_task_timing_active = 0;
    }
}

static int MPC_FinishExecute(uint32_t start_counter, int status)
{
    mpc_step_status = status;
    MPC_RecordTiming(&mpc_execute_timing, start_counter, status);
    return status;
}

/* 前回の結果を無効化し、失敗後に古い入力を今回の結果として使わせない。 */
void MPC_InvalidateResult(void)
{
    mpc_result_valid = 0;
    mpc_u0 = NAN;
    mpc_u1 = NAN;
    for (int i = 0; i < MPC_STATE_DIM; i++) mpc_x0[i] = NAN;
}

/* カプセル、計算領域、モデルを一度だけ作成する。制約値更新は別関数で行う。 */
int MPC_Init(void)
{
    (void)MPC_TimingInit();
    if (mpc_capsule != NULL) return mpc_create_status;
    mpc_capsule = interaction_model_acados_create_capsule();
    if (mpc_capsule == NULL)
    {
        mpc_create_status = -1;
        return mpc_create_status;
    }
    mpc_create_status = interaction_model_acados_create(mpc_capsule);
    if (mpc_create_status != 0) return mpc_create_status;

    /* 制約更新にはin、計算結果の取得にはoutを使う。 */
    mpc_config = interaction_model_acados_get_nlp_config(mpc_capsule);
    mpc_dims = interaction_model_acados_get_nlp_dims(mpc_capsule);
    mpc_in = interaction_model_acados_get_nlp_in(mpc_capsule);
    mpc_out = interaction_model_acados_get_nlp_out(mpc_capsule);
    mpc_solver = interaction_model_acados_get_nlp_solver(mpc_capsule);
    if (mpc_config == NULL || mpc_dims == NULL || mpc_in == NULL || mpc_out == NULL || mpc_solver == NULL)
    {
        mpc_create_status = -2;
        return mpc_create_status;
    }

    /* stage 0の制約を[v, x, k]へ対応させる。 */
    int idxbx[MPC_STATE_DIM] = {0, 1, 2};
    mpc_create_status = ocp_nlp_constraints_model_set(mpc_config, mpc_dims,
                          mpc_in, mpc_out, 0, "idxbx", idxbx);
    if (mpc_create_status == 0) mpc_create_status = MPC_ReadParameterBounds();
    if (mpc_create_status == 0) mpc_create_status = MPC_ReadInputBounds();
    return mpc_create_status;
}

/* p[0]の等価質量を全ステージへ設定する。ソルバ/カプセルを作り直さない。
 * 無効な値では古い結果を今回の結果として使わせず、solveできる状態も破棄する。
 */
int MPC_UpdateModelMass(double equivalent_mass)
{
    mpc_state_pending = 0;
    MPC_InvalidateResult();
    mpc_solve_status = -999;
    if (mpc_create_status != 0 || mpc_capsule == NULL)
        return (mpc_mass_update_status = -1);
    if (!isfinite(equivalent_mass) || equivalent_mass <= 0.0)
        return (mpc_mass_update_status = -2);

    double parameters[1] = {equivalent_mass};
    const int horizon = mpc_capsule->nlp_solver_plan->N;
    for (int stage = 0; stage <= horizon; ++stage)
    {
        mpc_mass_update_status = interaction_model_acados_update_params(
                                    mpc_capsule, stage, parameters, 1);
        if (mpc_mass_update_status != 0) return mpc_mass_update_status;
    }
    mpc_model_mass = equivalent_mass;
    return (mpc_mass_update_status = 0);
}

/* 実測状態を初期状態の等式として設定する：lbx[0]=ubx[0]=実測の3状態[v, x, k]。
   stage 1以降と終端の状態制約は、生成されたモデルの設定を維持する。 */
int MPC_UpdateInitialState(const double measured_state[MPC_STATE_DIM])
{
    mpc_state_pending = 0;
    MPC_InvalidateResult();
    mpc_solve_status = -999;
    mpc_update_status = -999;
    if (mpc_create_status != 0 || mpc_capsule == NULL)
        return (mpc_update_status = -1);
    if (measured_state == NULL) return (mpc_update_status = -2);

    /* 3値すべてを検査してから制約を変更し、NaN/Infや途中更新を避ける。 */
    double state[MPC_STATE_DIM];
    for (int i = 0; i < MPC_STATE_DIM; i++)
    {
        if (!isfinite(measured_state[i])) return (mpc_update_status = -2);
        state[i] = measured_state[i];
    }
    mpc_update_status = MPC_ValidateEstimatedState(state);
    if (mpc_update_status != 0) return mpc_update_status;
    mpc_update_status = ocp_nlp_constraints_model_set(mpc_config, mpc_dims,
                                mpc_in, mpc_out, 0, "lbx", state);
    if (mpc_update_status != 0) return mpc_update_status;
    mpc_update_status = ocp_nlp_constraints_model_set(mpc_config, mpc_dims,
                                mpc_in, mpc_out, 0, "ubx", state);
    if (mpc_update_status != 0) return mpc_update_status;

    /* 初期状態の初期推定値も測定値に合わせる。予測系列全体は再生成しない。 */
    ocp_nlp_out_set(mpc_config, mpc_dims, mpc_out, mpc_in, 0, "x", state);
    for (int i = 0; i < MPC_STATE_DIM; i++) mpc_measured_x[i] = state[i];
    mpc_state_pending = 1;
    return 0;
}

/* 入力の上下限を全予測入力へ設定する。起動時か、制約が変わったときに呼ぶ。
   1入力の現在のモデルが対象。更新はmainから行い、solveと同時に呼ばない。 */
int MPC_UpdateInputBounds(double lower, double upper)
{
    if (mpc_create_status != 0 || mpc_capsule == NULL) return -1;
    if (!isfinite(lower) || !isfinite(upper) || lower > upper) return -2;
    /* 有効な制約変更でも、変更前の計算結果・未実行状態入力は使い回さない。 */
    mpc_state_pending = 0;
    mpc_has_warm_start = 0;
    MPC_InvalidateResult();
    int idxbu[1] = {0};
    for (int k = 0; k < INTERACTION_MODEL_N; k++)
    {
        int status = ocp_nlp_constraints_model_set(mpc_config, mpc_dims,
                                      mpc_in, mpc_out, k, "idxbu", idxbu);
        if (status != 0) return status;
        status = ocp_nlp_constraints_model_set(mpc_config, mpc_dims,
                                      mpc_in, mpc_out, k, "lbu", &lower);
        if (status != 0) return status;
        status = ocp_nlp_constraints_model_set(mpc_config, mpc_dims,
                                      mpc_in, mpc_out, k, "ubu", &upper);
        if (status != 0) return status;
        mpc_stage_input_lower[k] = lower;
        mpc_stage_input_upper[k] = upper;
    }
    mpc_input_lower = lower;
    mpc_input_upper = upper;
    return 0;
}

/* 初期推定を準備する。初回・失敗後は全予測状態を今回の測定値で初期化する。
   元の生成コードの古いkを残したまま計算しない。
   成功後はLinux版と同じく前回入力列を1段ずらし、最後の入力は維持する。 */
static void MPC_PrepareWarmStart(void)
{
    /* 制約変更・失敗後は双対変数とQP内部状態もリセットする。
       更新した制約・モデル値・オプションは保持する。 */
    if (!mpc_has_warm_start) {
        /* Common acados API: keep numerical constraints, parameters and
           options, without depending on generated reset() signature versions. */
        ocp_nlp_out_set_values_to_zero(mpc_config, mpc_dims, mpc_out);
        ocp_nlp_solver_reset_qp_memory(mpc_solver, mpc_in, mpc_out);
    }
    for (int k = 0; k < INTERACTION_MODEL_N; k++)
    {
        double guess = mpc_has_warm_start
                       ? mpc_previous_u[k + 1 < INTERACTION_MODEL_N ? k + 1 : k]
                       : 0.0;
        guess = fmax(mpc_stage_input_lower[k], fmin(mpc_stage_input_upper[k], guess));
        ocp_nlp_out_set(mpc_config, mpc_dims, mpc_out, mpc_in, k, "u", &guess);
    }
    /* k is constant during this horizon. Every stage must use the current
       estimate before the one-step SQP_RTI linearization. After a successful
       solve, keep the previous velocity/position guesses and shifted inputs.
       On startup/failure, initialize every state from the current measurement. */
    for (int k = 0; k <= INTERACTION_MODEL_N; k++)
    {
        double state[MPC_STATE_DIM];
        if (mpc_has_warm_start)
            ocp_nlp_out_get(mpc_config, mpc_dims, mpc_out, k, "x", state);
        else
            for (int i = 0; i < MPC_STATE_DIM; i++) state[i] = mpc_measured_x[i];
        state[2] = mpc_measured_x[2];
        ocp_nlp_out_set(mpc_config, mpc_dims, mpc_out, mpc_in, k, "x", state);
    }
}

/* 今回の測定値で制約更新した後に、一度だけsolveを実行して結果を保存する。
   戻り値0=成功、正の値=acadosの失敗コード、負の値=入力/出力処理の失敗。 */
int MPC_Execute(void)
{
    const uint32_t execute_start = MPC_TimingNow();
    MPC_InvalidateResult();
    mpc_solve_status = -999;
    if (mpc_create_status != 0 || mpc_capsule == NULL)
        return MPC_FinishExecute(execute_start, -1);
    if (!mpc_state_pending) return MPC_FinishExecute(execute_start, -3);
    /* 同じ状態入力を、更新なしで再び計算に使わない。 */
    mpc_state_pending = 0;
    /* 予測値の準備は制約を変更する処理とは分けて行う。 */
    MPC_PrepareWarmStart();
    const uint32_t solve_start = MPC_TimingNow();
    mpc_solve_status = interaction_model_acados_solve(mpc_capsule);
    MPC_RecordTiming(&mpc_solver_timing, solve_start, mpc_solve_status);
    if (mpc_timing_ready && mpc_solver_timing.samples != 0U) {
        mpc_solve_time_us = mpc_solver_timing.last_us;
        mpc_solve_time_s = mpc_solver_timing.last_seconds;
        mpc_solve_time_ms = (uint32_t)(
            ((uint64_t)mpc_solver_timing.last_counter_ticks * 1000ULL) /
            mpc_timing_clock_hz);
    }
    mpc_iteration_count++;
    if (mpc_solve_status != 0)
    {
        mpc_failure_count++;
        mpc_has_warm_start = 0;
        return MPC_FinishExecute(execute_start, mpc_solve_status);
    }

    /* 今回の制御入力、次段の予測入力、固定された初期状態の出力を取得する。 */
    double u0[1], u1[1], x0[MPC_STATE_DIM];
    ocp_nlp_out_get(mpc_config, mpc_dims, mpc_out, 0, "u", u0);
	#if INTERACTION_MODEL_N >= 2
		ocp_nlp_out_get(mpc_config, mpc_dims, mpc_out, 1, "u", u1);
	#else
		u1[0] = u0[0];
	#endif
    ocp_nlp_out_get(mpc_config, mpc_dims, mpc_out, 0, "x", x0);
    int finite_result = isfinite(u0[0]) && isfinite(u1[0]);
    for (int i = 0; i < MPC_STATE_DIM; i++) finite_result = finite_result && isfinite(x0[i]);
    /* 次回用に全入力列を取得し、非有限値の列はウォームスタートに使わない。 */
    double sequence[INTERACTION_MODEL_N];
    for (int k = 0; k < INTERACTION_MODEL_N; k++)
    {
        ocp_nlp_out_get(mpc_config, mpc_dims, mpc_out, k, "u", &sequence[k]);
        finite_result = finite_result && isfinite(sequence[k]);
    }
    if (!finite_result)
    {
        mpc_failure_count++;
        mpc_has_warm_start = 0;
        return MPC_FinishExecute(execute_start, -4);
    }
    mpc_u0 = u0[0];
    mpc_u1 = u1[0];
    for (int i = 0; i < MPC_STATE_DIM; i++) mpc_x0[i] = x0[i];
    mpc_result_sample_id = mpc_sample_count;
    for (int k = 0; k < INTERACTION_MODEL_N; k++) mpc_previous_u[k] = sequence[k];
    mpc_has_warm_start = 1;
    mpc_success_count++;
    mpc_result_valid = 1;
    return MPC_FinishExecute(execute_start, 0);
}


/* センサ不正時の内部状態破棄をAPIにまとめ、mainからprivate変数を触らせない。 */
void MPC_DiscardState(void)
{
    mpc_state_pending = 0;
    mpc_has_warm_start = 0;
    MPC_InvalidateResult();
}
