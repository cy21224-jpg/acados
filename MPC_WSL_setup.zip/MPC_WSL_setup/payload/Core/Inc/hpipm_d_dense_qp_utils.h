/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_d_dense_qp_utils.h"
