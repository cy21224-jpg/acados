/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_aux_mem.h"
