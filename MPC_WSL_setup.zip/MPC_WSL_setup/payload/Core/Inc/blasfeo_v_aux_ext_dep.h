/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_v_aux_ext_dep.h"
