/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_d_core_qp_ipm_aux.h"
