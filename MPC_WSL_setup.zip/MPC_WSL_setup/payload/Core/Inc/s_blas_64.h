/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/s_blas_64.h"
