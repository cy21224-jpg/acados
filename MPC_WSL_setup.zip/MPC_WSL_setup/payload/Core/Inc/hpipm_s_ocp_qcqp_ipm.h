/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_s_ocp_qcqp_ipm.h"
