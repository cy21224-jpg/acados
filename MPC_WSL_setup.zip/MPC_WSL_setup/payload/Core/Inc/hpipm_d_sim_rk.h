/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_d_sim_rk.h"
