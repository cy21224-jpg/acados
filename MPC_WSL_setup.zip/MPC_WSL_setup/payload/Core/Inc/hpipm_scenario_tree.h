/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_scenario_tree.h"
