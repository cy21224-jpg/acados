/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_s_part_cond.h"
