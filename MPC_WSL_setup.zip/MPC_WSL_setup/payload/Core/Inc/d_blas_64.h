/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/d_blas_64.h"
