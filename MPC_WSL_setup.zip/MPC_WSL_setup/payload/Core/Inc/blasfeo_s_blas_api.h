/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_s_blas_api.h"
