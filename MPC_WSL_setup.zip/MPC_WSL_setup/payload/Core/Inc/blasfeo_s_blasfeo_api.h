/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_s_blasfeo_api.h"
