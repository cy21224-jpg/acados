/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_s_aux_ext_dep.h"
