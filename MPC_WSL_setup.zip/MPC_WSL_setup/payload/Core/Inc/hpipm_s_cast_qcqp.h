/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_s_cast_qcqp.h"
