/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_s_blasfeo_ref_api.h"
