/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_timing.h"
