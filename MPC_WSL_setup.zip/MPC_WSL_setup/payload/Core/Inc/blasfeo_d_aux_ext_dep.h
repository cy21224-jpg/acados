/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_d_aux_ext_dep.h"
