/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_d_part_cond_qcqp.h"
