/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_d_ocp_qcqp_utils.h"
