/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_s_tree_ocp_qcqp.h"
