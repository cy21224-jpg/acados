/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_d_aux_ref.h"
