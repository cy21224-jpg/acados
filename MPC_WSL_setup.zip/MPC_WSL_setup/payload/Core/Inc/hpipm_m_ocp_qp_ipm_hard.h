/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_m_ocp_qp_ipm_hard.h"
