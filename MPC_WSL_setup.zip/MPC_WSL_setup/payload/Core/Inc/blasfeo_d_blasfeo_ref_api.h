/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_d_blasfeo_ref_api.h"
