/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_s_core_qp_ipm.h"
