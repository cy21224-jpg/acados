/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_s_sim_erk.h"
