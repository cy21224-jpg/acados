/* Added compatibility include; vendor headers are retained. */
#include "blasfeo/include/blasfeo_timing.h"
