/* Added compatibility include; vendor headers are retained. */
#include "hpipm/include/hpipm_d_tree_ocp_qp_kkt.h"
